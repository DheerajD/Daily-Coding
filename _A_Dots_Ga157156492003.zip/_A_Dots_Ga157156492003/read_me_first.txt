Instructions:
-copy the file "comm.h" in your "include" folder
-copy the file "egavga.bgi" in your "bin" folder

Rules:
-use the cursor to place lines between dots
-create boxes to score 
-player with most boxes wins

Controls:
-move cursor : up, down, left, right
-place line : ENTER
-change line type ( vertical, horizontal ) : SPACEBAR